from __future__ import annotations

__lazy_modules__ = {f"{__spec__.parent}.namedhist"}

import importlib.util

if not importlib.util.find_spec("dask_histogram"):
    msg = """for hist.dask, install the 'dask_histogram' package with:
        pip install dask_histogram
        or
        conda install dask_histogram"""
    raise ModuleNotFoundError(msg)

from .hist import Hist
from .namedhist import NamedHist

new = Hist.new

__all__ = ["Hist", "NamedHist", "new"]
