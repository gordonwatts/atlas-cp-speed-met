# Copyright (c) 2020, Henry Schreiner
#
# Distributed under the 3-clause BSD license, see accompanying file LICENSE
# or https://github.com/scikit-hep/hist for details.

from __future__ import annotations

__lazy_modules__ = {
    "warnings",
    f"{__spec__.parent}",
    f"{__spec__.parent}.basehist",
    f"{__spec__.parent}.namedhist",
    f"{__spec__.parent}.stack",
    f"{__spec__.parent}.tag",
    f"{__spec__.parent}.version",
}

import warnings
from typing import TYPE_CHECKING

from . import accumulators, axis, numpy, storage, tag
from .basehist import BaseHist
from .hist import Hist
from .namedhist import NamedHist
from .stack import Stack
from .tag import (
    at,
    loc,
    overflow,
    rebin,
    sum,
    underflow,
)

# Convenient access to the version number
from .version import version as __version__

if TYPE_CHECKING:
    from types import ModuleType

__all__ = (
    "BaseHist",
    "Hist",
    "NamedHist",
    "Stack",
    "__version__",
    "accumulators",
    "at",
    "axis",
    "loc",
    "new",
    "numpy",
    "overflow",
    "rebin",
    "storage",
    "sum",
    "tag",
    "underflow",
)


new = Hist.new


def __dir__() -> tuple[str, ...]:
    return __all__


def __getattr__(name: str) -> ModuleType:
    if name == "axes":
        msg = f"Misspelling error, '{name}' should be 'axis'"
        warnings.warn(msg, stacklevel=2)
        return axis
    msg_0 = f"module {__name__} has no attribute {name}"
    raise AttributeError(msg_0)
