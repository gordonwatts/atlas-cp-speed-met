from __future__ import annotations

import json
import zipfile
from typing import Any

import numpy as np

from ..typing.serialization import AnyHistogramIR, ToUHIHistogram
from . import ARRAY_KEYS
from ._common import _check_uhi_schema_version, _convert_input

__all__ = ["read", "write"]


def __dir__() -> list[str]:
    return __all__


def write(
    zip_file: zipfile.ZipFile,
    /,
    name: str,
    histogram: AnyHistogramIR | ToUHIHistogram,
) -> None:
    """
    Write a histogram to a zip file.
    """
    histogram = _convert_input(histogram)
    # Copy the histogram and the dicts/lists we mutate below so the caller's
    # arrays are not replaced with path strings.
    histogram = histogram.copy()

    # Write out numpy arrays to files in the zipfile
    storage = histogram["storage"].copy()
    histogram["storage"] = storage
    for storage_key in ARRAY_KEYS & storage.keys():
        path = f"{name}_storage_{storage_key}.npy"
        with zip_file.open(path, "w") as f:
            np.save(f, storage[storage_key])  # type: ignore[literal-required]
        storage[storage_key] = path  # type: ignore[literal-required]

    axes = [axis.copy() for axis in histogram["axes"]]
    histogram["axes"] = axes
    for i, axis in enumerate(axes):
        for key in ARRAY_KEYS & axis.keys():
            path = f"{name}_axis_{i}_{key}.npy"
            with zip_file.open(path, "w") as f:
                np.save(f, axis[key])  # type: ignore[literal-required]
            axis[key] = path  # type: ignore[literal-required]

    hist_json = json.dumps(histogram)
    zip_file.writestr(f"{name}.json", hist_json)


def _load_arrays(dct: dict[str, Any], /, *, zip_file: zipfile.ZipFile) -> None:
    """
    Replace the stored paths with the arrays they point at, in-place.
    """
    for item in ARRAY_KEYS & dct.keys():
        if isinstance(dct[item], str):
            dct[item] = np.load(zip_file.open(dct[item]))


def read(zip_file: zipfile.ZipFile, /, name: str) -> dict[str, Any]:
    """
    Read histograms from a zip file.
    """

    with zip_file.open(f"{name}.json") as f:
        output: dict[str, Any] = json.load(f)
    _check_uhi_schema_version(output["uhi_schema"])

    # Only storage and axes hold arrays; metadata and writer_info can contain
    # any keys, including ones that look like array keys.
    _load_arrays(output["storage"], zip_file=zip_file)
    for axis in output["axes"]:
        _load_arrays(axis, zip_file=zip_file)

    return output
