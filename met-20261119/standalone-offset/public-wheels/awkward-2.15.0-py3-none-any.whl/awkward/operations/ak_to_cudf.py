# BSD 3-Clause License; see https://github.com/scikit-hep/awkward/blob/main/LICENSE

import awkward as ak
from awkward._dispatch import high_level_function

__all__ = ("to_cudf",)


@high_level_function()
def to_cudf(array):
    """Converts an Awkward Array into a cuDF Series.

    Buffers that are not already in GPU memory will be transferred, and some
    structural reformatting may happen to account for differences in
    architecture.

    This function requires the `cudf` library and a compatible GPU.

    See also #ak.to_cupy, #ak.from_cupy, #ak.to_dataframe.

    Args:
        array: Array-like data (anything #ak.to_layout recognizes).

    Returns:
        A cuDF Series with the same data as `array`.
    """
    # Dispatch
    yield (array,)

    # Implementation
    return _impl(array)


def _impl(array):
    try:
        import cudf
    except ImportError as err:
        raise ImportError(
            """to use ak.to_cudf, you must install the 'cudf' package with:

    pip install cudf-cu13
or
    conda install -c rapidsai cudf cuda-version=13"""
        ) from err

    layout = ak.to_layout(array, allow_record=False)

    if hasattr(cudf.Series, "_from_column"):
        return cudf.Series._from_column(layout._to_cudf(cudf, None, len(layout)))
    # older Series invocation
    return cudf.Series(layout._to_cudf(cudf, None, len(layout)))
