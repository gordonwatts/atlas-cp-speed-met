# BSD 3-Clause License; see https://github.com/scikit-hep/awkward/blob/main/LICENSE


from collections.abc import Mapping, Sequence
from functools import reduce
from typing import Any

import awkward as ak
from awkward._dispatch import high_level_function
from awkward._layout import HighLevelContext, ensure_same_backend
from awkward._namedaxis import _get_named_axis, _unify_named_axis
from awkward._nplikes.placeholder import PlaceholderArray
from awkward._nplikes.shape import UnknownLength

__all__ = ("zip_no_broadcast",)


@high_level_function()
def zip_no_broadcast(
    arrays: Mapping[str, Any] | Sequence[Any],
    *,
    parameters: dict | None = None,
    with_name: str | None = None,
    highlevel: bool = True,
    behavior: dict | None = None,
    attrs: dict | None = None,
):
    """Combines arrays into a collection of records or tuples without broadcasting.

    Caution: unlike #ak.zip this function will _not_ broadcast the arrays
    together. During typetracing, it assumes that the given arrays have already
    the same layouts and lengths.

    This operation may be thought of as the opposite of projection in
    #ak.Array.__getitem__, which extracts fields one at a time, or #ak.unzip,
    which extracts them all in one call.

    Only #ak.contents.NumpyArray layouts and #ak.contents.ListOffsetArray
    layouts with NumpyArray contents are supported. List contents such as
    strings, records, options, or further nested lists raise NotImplementedError;
    use #ak.zip
    for those layouts.

    See also #ak.zip and #ak.unzip.

    Args:
        arrays (mapping or sequence of arrays): Each value in this mapping or
            sequence can be any array-like data that #ak.to_layout recognizes.
        parameters (None or dict): Parameters for the new
            #ak.contents.RecordArray node that is created by this operation.
        with_name (None or str): Assigns a `"__record__"` name to the new
            #ak.contents.RecordArray node that is created by this operation
            (overriding `parameters`, if necessary).
        highlevel (bool): If True, return an #ak.Array; otherwise, return
            a low-level #ak.contents.Content subclass.
        behavior (None or dict): Custom #ak.behavior for the output array, if
            high-level.
        attrs (None or dict): Custom attributes for the output array, if
            high-level.

    Returns:
        An array of records (or tuples) whose fields (or slots) are the
        `arrays`, combined into a single structure.

    Examples:
        Consider the following arrays, `one` and `two`.

        >>> one = ak.Array([[1.1, 2.2, 3.3], [], [4.4, 5.5], [6.6]])
        >>> two = ak.Array([[1, 2, 3], [], [4, 5], [6]])

        Zipping them together using a dict creates a collection of records with
        the same nesting structure as `one` and `two`.

        >>> ak.zip_no_broadcast({"x": one, "y": two}).show()
        [[{x: 1.1, y: 1}, {x: 2.2, y: 2}, {x: 3.3, y: 3}],
         [],
         [{x: 4.4, y: 4}, {x: 5.5, y: 5}],
         [{x: 6.6, y: 6}]]

        Doing so with a list creates tuples, whose fields are not named.

        >>> ak.zip_no_broadcast([one, two]).show()
        [[(1.1, 1), (2.2, 2), (3.3, 3)],
         [],
         [(4.4, 4), (5.5, 5)],
         [(6.6, 6)]]
    """
    # Dispatch: provide the underlying arrays to the dispatcher
    if isinstance(arrays, Mapping):
        yield arrays.values()
    else:
        arrays = list(arrays)
        yield arrays

    return _impl(arrays, parameters, with_name, highlevel, behavior, attrs)


def _impl(
    arrays: Mapping[str, Any] | Sequence[Any],
    parameters: dict | None,
    with_name: str | None,
    highlevel: bool,
    behavior: dict | None,
    attrs: dict | None,
):
    with HighLevelContext(behavior=behavior, attrs=attrs) as ctx:
        if isinstance(arrays, Mapping):
            values = list(arrays.values())
            layouts = ensure_same_backend(
                *(
                    ctx.unwrap(
                        x,
                        allow_record=False,
                        allow_unknown=False,
                        none_policy="pass-through",
                        primitive_policy="pass-through",
                    )
                    for x in values
                )
            )
            fields = list(arrays.keys())
            out_named_axis = (
                reduce(_unify_named_axis, map(_get_named_axis, values))
                if values
                else None
            )
        else:
            seq = list(arrays)
            layouts = ensure_same_backend(
                *(
                    ctx.unwrap(
                        x,
                        allow_record=False,
                        allow_unknown=False,
                        none_policy="pass-through",
                        primitive_policy="pass-through",
                    )
                    for x in seq
                )
            )
            fields = None
            out_named_axis = (
                reduce(_unify_named_axis, map(_get_named_axis, seq)) if seq else None
            )

    if not layouts:
        raise ValueError("zip_no_broadcast requires at least one array")

    if with_name is not None:
        parameters = dict(parameters) if parameters is not None else {}
        parameters["__record__"] = with_name

    if all(isinstance(layout, ak.contents.NumpyArray) for layout in layouts):
        backend = layouts[0].backend
        length = _check_equal_lengths(layouts)
        out = ak.contents.RecordArray(
            layouts,
            fields,
            length=length,
            parameters=parameters,
            backend=backend,
        )

    elif all(isinstance(layout, ak.contents.ListOffsetArray) for layout in layouts):
        backend = layouts[0].backend
        contents: list[ak.contents.Content] = []
        for layout in layouts:
            if not isinstance(layout.content, ak.contents.NumpyArray):
                msg = (
                    "ak.zip_no_broadcast cannot (safely) zip ListOffsetArrays whose "
                    "contents are not NumpyArray. Use ak.zip instead."
                )
                raise NotImplementedError(msg)
            contents.append(layout.content)

        if backend.name == "typetracer":
            offsets = layouts[0].offsets
        else:
            comparable_offsets = [
                layout.offsets
                for layout in layouts
                if not isinstance(layout.offsets.data, PlaceholderArray)
            ]

            if comparable_offsets:
                first = comparable_offsets[0]
                if not all(
                    other.length == first.length
                    and first.nplike.all(other.data == first.data)
                    for other in comparable_offsets
                ):
                    raise ValueError("all ListOffsetArrays must have the same offsets")
                offsets = first
            else:
                offsets = layouts[0].offsets

        length = _check_equal_lengths(contents)
        out = ak.contents.ListOffsetArray(
            offsets=offsets,
            content=ak.contents.RecordArray(
                contents,
                fields,
                length=length,
                parameters=parameters,
                backend=backend,
            ),
        )
    else:
        raise ValueError(
            "all array layouts must be either NumpyArrays or ListOffsetArrays"
        )

    wrapped_out = ctx.wrap(out, highlevel=highlevel)

    return ak.operations.ak_with_named_axis._impl(
        wrapped_out,
        named_axis=out_named_axis,
        highlevel=highlevel,
        behavior=ctx.behavior,
        attrs=ctx.attrs,
    )


def _check_equal_lengths(
    contents: Sequence[ak.contents.Content],
) -> int | UnknownLength:
    """
    Ensure all layouts in ``contents`` have the same length and return that
    length.

    ``UnknownLength`` is returned when lengths are not statically known
    (typetracer/placeholder scenarios).
    """
    if not contents:
        raise ValueError("_check_equal_lengths requires at least one content")

    length = contents[0].length
    for layout in contents:
        if layout.length != length:
            raise ValueError("all arrays must have the same length")

    return length
