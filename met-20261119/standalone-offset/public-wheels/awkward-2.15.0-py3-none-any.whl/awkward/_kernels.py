# BSD 3-Clause License; see https://github.com/scikit-hep/awkward/blob/main/LICENSE


import ctypes
from abc import abstractmethod
from collections.abc import Callable
from typing import Any

from packaging.version import parse as parse_version

import awkward as ak
from awkward._nplikes.array_like import maybe_materialize
from awkward._nplikes.cupy import Cupy
from awkward._nplikes.jax import Jax
from awkward._nplikes.numpy import Numpy
from awkward._nplikes.numpy_like import NumpyMetadata
from awkward._nplikes.typetracer import try_touch_data
from awkward._typing import Protocol, TypeAlias

# Tuple[str, Unpack[Tuple[metadata.dtype, ...]]]
KernelKeyType: TypeAlias = tuple


numpy = Numpy.instance()
metadata = NumpyMetadata.instance()


class KernelError(Protocol):
    filename: bytes | None
    str: bytes | None
    attempt: int
    id: int


class Kernel(Protocol):
    @property
    @abstractmethod
    def key(self) -> KernelKeyType: ...

    @abstractmethod
    def __call__(self, *args) -> KernelError | None:
        raise NotImplementedError


class BaseKernel(Kernel):
    _impl: Callable[..., Any]
    _key: KernelKeyType

    def __init__(self, impl: Callable[..., Any], key: KernelKeyType):
        self._impl = impl
        self._key = key

    @property
    def key(self) -> KernelKeyType:
        return self._key

    def __repr__(self):
        return "<{} {}{}>".format(
            type(self).__name__,
            self.key[0],
            "".join(", " + str(metadata.dtype(x)) for x in self.key[1:]),
        )


class CTypesKernel(BaseKernel):
    """A kernel compiled into awkward-cpp, called through ctypes.

    The NumPy and JAX backends both dispatch to these functions -- which is why
    the JAX backend requires its buffers to live on the CPU -- so they share the
    calling convention here and differ only in how a buffer's address is taken.
    """

    def __init__(self, impl: Callable[..., Any], key: KernelKeyType):
        super().__init__(impl, key)
        argtypes = impl.argtypes
        self._is_pointer = tuple(issubclass(t, ctypes._Pointer) for t in argtypes)
        # Building a typed ctypes pointer for each buffer costs several times as
        # much as the call itself, so re-prototype the same function address
        # with `void *` parameters and hand it plain addresses instead.
        self._call = ctypes.CFUNCTYPE(
            impl.restype,
            *(
                ctypes.c_void_p if is_pointer else t
                for is_pointer, t in zip(self._is_pointer, argtypes, strict=True)
            ),
        )(ctypes.cast(impl, ctypes.c_void_p).value)

    def _pointer_of(self, x):
        """The address of ``x``'s buffer, rejecting anything this backend cannot pass."""
        raise NotImplementedError

    def __call__(self, *args) -> None:
        assert len(args) == len(self._is_pointer)

        args = maybe_materialize(*args)
        pointer_of = self._pointer_of

        return self._call(
            *(
                pointer_of(x) if is_pointer else x
                for x, is_pointer in zip(args, self._is_pointer, strict=True)
            )
        )


class NumpyKernel(CTypesKernel):
    def _pointer_of(self, x):
        # Do we have a NumPy-owned array?
        if numpy.is_own_array(x):
            assert x.flags.c_contiguous, "kernel expects contiguous array"
            if x.ndim > 0:
                return x.ctypes.data
            else:
                return x
        # Or, do we have a ctypes type
        elif hasattr(x, "_b_base_"):
            return ctypes.cast(x, ctypes.c_void_p)
        else:
            raise AssertionError(
                f"Only NumPy buffers should be passed to Numpy Kernels, received {x}"
            )


class JaxKernel(CTypesKernel):
    def __init__(self, impl: Callable[..., Any], key: KernelKeyType):
        super().__init__(impl, key)

        self._jax = Jax.instance()

        jax_module = ak.jax.import_jax()
        self._ad_tracer_types = (jax_module._src.interpreters.ad.JVPTracer,)
        if parse_version(jax_module.__version__) >= parse_version("0.7.0"):
            self._ad_tracer_types += (jax_module._src.interpreters.ad.LinearizeTracer,)

    def _pointer_of(self, x):
        # Do we have a JAX-owned array?
        if self._jax.is_own_array(x):
            if self._jax.is_tracer_type(type(x)):
                # general message for any invalid JAX input type
                msg = f"Encountered {x} as an (invalid) input to the '{self._key[0]}' Awkward C++ kernel."
                # message specification for autodiff (i.e. when encountering a JVPTracer)
                if isinstance(x, self._ad_tracer_types):
                    msg += " This kernel is not differentiable by the JAX backend."
                raise ValueError(msg)
            assert self._jax.is_c_contiguous(x), "kernel expects contiguous array"
            if x.ndim > 0:
                if x.device.platform != "cpu":
                    raise RuntimeError(
                        "The JAX backend requires CPU JAX buffers to be the default. You can make CPU the default backend"
                        " with jax.config.update('jax_platform_name', 'cpu') or by setting JAX_PLATFORM_NAME=cpu."
                    )
                return self._jax.memory_ptr(x)
            else:
                return x
        # Or, do we have a ctypes type
        elif hasattr(x, "_b_base_"):
            return ctypes.cast(x, ctypes.c_void_p)
        else:
            raise AssertionError(
                f"Only JAX buffers should be passed to JAX Kernels, received {x}"
            )


class CupyKernel(BaseKernel):
    def __init__(self, impl: Callable[..., Any], key: KernelKeyType):
        super().__init__(impl, key)

        self._cupy = Cupy.instance()

    def max_length(self, args):
        max_length = metadata.iinfo(metadata.int64).min
        # TODO should kernels strip nplike wrapper? Probably
        for array in args:
            if self._cupy.is_own_array(array):
                max_length = max(max_length, array.size)
        return max_length

    def calc_grid(self, length):
        # CUDA blocks are limited to 1024 threads per block, so to
        # have more than one block, we have at least `length // 1024` blocks
        # of size 1024.
        return (length // 1024) + 1, 1, 1

    def calc_blocks(self, length):
        # CUDA blocks are limited to 1024 threads per block
        # Number of threads are given by `length`
        return min(length, 1024), 1, 1

    def __call__(self, *args) -> None:
        import awkward._connect.cuda as ak_cuda

        args = maybe_materialize(*args)

        cupy = ak_cuda.import_cupy("Awkward Arrays with CUDA")
        maxlength = self.max_length(args)
        grid, blocks = self.calc_grid(maxlength), self.calc_blocks(maxlength)
        cupy_stream_ptr = cupy.cuda.get_current_stream().ptr

        if cupy_stream_ptr not in ak_cuda.cuda_streamptr_to_contexts:
            ak_cuda.cuda_streamptr_to_contexts[cupy_stream_ptr] = (
                cupy.array(ak_cuda.NO_ERROR),
                [],
            )
        elif (
            len(ak_cuda.cuda_streamptr_to_contexts[cupy_stream_ptr][1])
            >= ak_cuda.MAX_PENDING_INVOCATIONS
        ):
            # Bound the pending-invocation list: workloads that never call
            # synchronize_cuda would otherwise accumulate Invocations (and
            # the buffers their ErrorContexts reference) without limit. One
            # stream synchronization per MAX_PENDING_INVOCATIONS launches is
            # amortized noise; pending errors surface here, which only makes
            # them earlier than the next explicit synchronization.
            ak_cuda.synchronize_cuda(cupy.cuda.get_current_stream())
        assert len(args) == len(self._impl.is_ptr)

        # a CuPy kernel takes the arrays themselves, so there is nothing to convert
        assert all(
            self._cupy.is_c_contiguous(x)
            for x, is_ptr in zip(args, self._impl.is_ptr, strict=True)
            if is_ptr and self._cupy.is_own_array(x)
        ), "kernel expects contiguous arrays"

        # The first arg is the invocation index which raises itself by 8 in the kernel if there was no error before.
        # The second arg is the error_code.
        args = (
            *args,
            len(ak_cuda.cuda_streamptr_to_contexts[cupy_stream_ptr][1]),
            ak_cuda.cuda_streamptr_to_contexts[cupy_stream_ptr][0],
        )
        ak_cuda.cuda_streamptr_to_contexts[cupy_stream_ptr][1].append(
            ak_cuda.Invocation(
                name=self.key[0],
                error_context=ak._errors.ErrorContext.frozen_primary(),
            )
        )

        self._impl(grid, blocks, args)


class CudaComputeKernel(BaseKernel):
    """
    Kernel implementation using cuda.compute library.

    When the CUDA backend is used, this kernel is used for operations
    that have ``cuda.compute`` implementations. For other operations,
    the ``CupyKernel`` is used.
    """

    def __init__(self, impl: Callable[..., Any], key: KernelKeyType):
        super().__init__(impl, key)
        self._cupy = Cupy.instance()

    def __call__(self, *args) -> None:
        import awkward._connect.cuda as ak_cuda

        args = maybe_materialize(*args)

        cupy = ak_cuda.import_cupy("Awkward Arrays with CUDA")
        # initialize `cupy_stream_ptr` which is used in tests-cuda-kernels-explicit
        # (for example, if we call awkward._connect.cuda.synchronize_cuda())
        cupy_stream_ptr = cupy.cuda.get_current_stream().ptr

        if cupy_stream_ptr not in ak_cuda.cuda_streamptr_to_contexts:
            ak_cuda.cuda_streamptr_to_contexts[cupy_stream_ptr] = (
                cupy.array(ak_cuda.NO_ERROR),
                [],
            )
        elif (
            len(ak_cuda.cuda_streamptr_to_contexts[cupy_stream_ptr][1])
            >= ak_cuda.MAX_PENDING_INVOCATIONS
        ):
            # See CupyKernel.__call__: bound the pending-invocation list.
            ak_cuda.synchronize_cuda(cupy.cuda.get_current_stream())
        ak_cuda.cuda_streamptr_to_contexts[cupy_stream_ptr][1].append(
            ak_cuda.Invocation(
                name=self.key[0],
                error_context=ak._errors.ErrorContext.frozen_primary(),
            )
        )

        return self._impl(*args)


class TypeTracerKernelError(KernelError):
    def __init__(self):
        self.str = None
        self.filename = None
        self.attempt = ak._util.kSliceNone
        self.id = ak._util.kSliceNone


class TypeTracerKernel:
    def __init__(self, index):
        self._name_and_types = index

    def __call__(self, *args) -> TypeTracerKernelError:
        for arg in args:
            try_touch_data(arg)
        return TypeTracerKernelError()

    def __repr__(self):
        return "<{} {}{}>".format(
            type(self).__name__,
            self._name_and_types[0],
            "".join(", " + str(metadata.dtype(x)) for x in self._name_and_types[1:]),
        )
