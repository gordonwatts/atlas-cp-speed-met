"""Frozen ROOT-free MET provider and payloads."""
from ctypes import CDLL, RTLD_GLOBAL
from pathlib import Path
_native = Path(__file__).parent / "native"
_gcc = CDLL(str(_native / "libgcc_s.so.1"), mode=RTLD_GLOBAL)
_cpp = CDLL(str(_native / "libstdc++.so.6"), mode=RTLD_GLOBAL)
